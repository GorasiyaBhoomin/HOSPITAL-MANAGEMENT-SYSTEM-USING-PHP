<?php
include_once("example_create_database.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap Bundle with Popper.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
<script src="js/additional-methods.js"></script>
    <script>
        $(document).ready(function () {
            $("#registrationForm").validate({
                rules: {
                    name: {
                        required: true,
                        minlength: 2
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    password: {
                        required: true,
                        minlength: 6
                    },
                    mobile: {
                        required: true,
                        digits: true,
                        minlength: 10,
                        maxlength: 10
                    },
                    state: {
                        minlength: 2
                    },
                    gender: {
                        required: true
                    },
                    "hobbies[]": {
                        required: true,
                        minlength: 1
                    },
                    photo: {
                        accept: "image/*"
                    }
                },
                messages: {
                    name: {
                        required: "Please enter your name",
                        minlength: "Name must be at least 2 characters long"
                    },
                    email: {
                        required: "Please enter your email",
                        email: "Enter a valid email address"
                    },
                    password: {
                        required: "Please enter a password",
                        minlength: "Password must be at least 6 characters"
                    },
                    mobile: {
                        required: "Please enter your mobile number",
                        digits: "Only numbers are allowed",
                        minlength: "Mobile number must be 10 digits",
                        maxlength: "Mobile number must be 10 digits"
                    },
                    state: {
                        minlength: "State name must be at least 2 characters long"
                    },
                    gender: {
                        required: "Please select your gender"
                    },
                    "hobbies[]": {
                        required: "Please select at least one hobby"
                    },
                    photo: {
                        accept: "Only image files are allowed"
                    }
                },
                errorElement: "span",
        errorPlacement: function (error, element) {
            if (element.attr("name") === "gender") {
                error.addClass("text-danger d-block").insertAfter("#gender-options");
            } else {
                error.addClass("text-danger").insertAfter(element);
            }
        },
        highlight: function (element) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },
        unhighlight: function (element) {
            $(element).addClass("is-valid").removeClass("is-invalid");
        }
    });
});
    </script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 500px;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
            margin-top: 50px;
        }
        button {
            width: 100%;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2 class="text-center mb-4">User Registration</h2>
        <form action="register.php"  id="registrationForm" method="POST" enctype="multipart/form-data">
            
            <div class="mb-3">
                <label for="name" class="form-label">Name:</label>
                <input type="text" class="form-control" id="name" name="name">
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email:</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password:</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>

            <div class="mb-3">
                <label for="mobile" class="form-label">Mobile:</label>
                <input type="text" class="form-control" id="mobile" name="mobile">
            </div>

            <div class="mb-3">
                <label for="state" class="form-label">State:</label>
                <input type="text" class="form-control" id="state" name="state">
            </div>

            <div class="mb-3">
                <label class="form-label">Gender:</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" value="Male">
                    <label class="form-check-label">Male</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" value="Female">
                    <label class="form-check-label">Female</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" value="Other">
                    <label class="form-check-label">Other</label>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">Hobbies:</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="hobbies[]" value="Reading">
                    <label class="form-check-label">Reading</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="hobbies[]" value="Sports">
                    <label class="form-check-label">Sports</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="hobbies[]" value="Music">
                    <label class="form-check-label">Music</label>
                </div>
            </div>

            <div class="mb-3">
                <label for="photo" class="form-label">Profile Picture:</label>
                <input type="file" class="form-control" id="photo" name="photo" accept="image/*">
            </div>

<button type="submit" class="btn btn-primary" id="reg_btn" name="reg_btn">Register</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php
if(isset($_POST['reg_btn'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $mobile = $_POST['mobile'];
    $state = $_POST['state'];
    $gender = $_POST['gender'];
    $hobbies = implode(",",$_POST['hobbies']);
    $photo = uniqid().$_FILES['photo']['name'];

    $insert = "INSERT INTO register (name, email, password, mobile, state, gender, hobbies, photo)
    VALUES ('$name', '$email', '$password', '$mobile', '$state', '$gender', '$hobbies', '$photo')";


    try{
        if($con->query($insert)){
            if(!is_dir("photo")){
                mkdir("photo");
            }
            move_uploaded_file($_FILES['photo']['tmp_name'], "photo/" . $photo);

            setcookie('success','data inserted successfully',time()+5,"/");
        }
        }catch (Exception $e){
            echo"error inserting data";
            setcookie('error','error inserting data',time()+5,"/");
        }
    }
?>