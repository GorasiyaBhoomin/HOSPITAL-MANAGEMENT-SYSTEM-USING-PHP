<?php
include_once ("connection.php");

$q ="Select * from register";


?>