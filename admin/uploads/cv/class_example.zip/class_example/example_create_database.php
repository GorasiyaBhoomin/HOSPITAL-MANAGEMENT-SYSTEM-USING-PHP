<?php

try {
    // Establishing connection
    $con = new mysqli("localhost", "root","", "2025_4ce_2");

    // if ($con->connect_error) {
    //     throw new Exception("Connection failed: " . $con->connect_error);
    // }
    // echo "Connected successfully<br>";

    // Create database (uncomment if needed)
    // $db = "CREATE DATABASE 2025_4ce_2";
    // if ($con->query($db) === TRUE) {
    //     echo "Database created successfully";
    // } else {
    //     throw new Exception("Error creating database: " . $con->error);
    // }

    // Selecting database
    $con->select_db("2025_4ce_2");

    // $register = "CREATE TABLE IF NOT EXISTS register (
    //     id INT AUTO_INCREMENT PRIMARY KEY,
    //     name VARCHAR(50) NOT NULL,
    //     email VARCHAR(50) NOT NULL UNIQUE,
    //     password VARCHAR(255) NOT NULL,
    //     mobile VARCHAR(255) NOT NULL,
    //     state CHAR(10),
    //     gender CHAR(10),
    //     hobbies VARCHAR(255),
    //     photo VARCHAR(255)
    // )";

    // Executing table creation query
    // if ($con->query($register) === TRUE) {
    //     echo "Table 'register' is ready.<br>";
    // } else {
    //     throw new Exception("Error creating table: " . $con->error);
    // }

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

// Closing connection
?>
